package org.greh;

import com.badlogic.gdx.Application;
import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import org.greh.apps.AudioVisualizer;

public class BaseApp extends Game {

    
    // interface to Platfor specific communication.
    public interface IOperatingSystemCommands {

        int CMD_TOAST = 1;  // data format: str_message, bool_short_time

        // show list of texts and upon click respective runnables are run
        public void show_list(String title, String texts[], Runnable runnables[]);

        public void show_messagebox(String message);

//        public Object get(String key, Object default_value);
//
//        public void set(String key, Object value);

        // runnable to run on main application thread
        // of operating system application. E.g. on Android it is runOnUiThread(Runnable)
        public void post_runnable(Runnable runnable);

        public void command(int command, Object data[]);

    }

    static public boolean DEBUG = false; // debug control flag

    public GuiDrawUtil M_drawutil;
    
    public IOperatingSystemCommands M_os;
    public AudioVisualizer M_mainscreen;

    public BaseApp(IOperatingSystemCommands os) {
        M_os = os;
    }

    @Override
    public void create() {
        if (DEBUG) {
            Gdx.app.setLogLevel(Application.LOG_DEBUG);
        }

        AppCfg.WIDTH = Gdx.graphics.getWidth();
        AppCfg.HEIGHT = Gdx.graphics.getHeight();

        M_drawutil = new GuiDrawUtil();
                
        // handle Android's Menu and Back keys
        Gdx.input.setCatchBackKey(true);
        Gdx.input.setCatchMenuKey(true);

        // show list of apps and let user choose one
        M_os.show_list("", new String[]{"AudioVisualizer"},
                new Runnable[]{ new Runnable() {
                    @Override
                    public void run() {
                        Gdx.app.postRunnable(new Runnable() {
                            public void run() {
                                M_mainscreen = new AudioVisualizer(BaseApp.this);
                                setScreen(M_mainscreen);
                            }
                        });
                    }
                }
                });

    }

    @Override
    public void dispose() {
        M_mainscreen = null;
        M_drawutil.dispose();
        M_drawutil = null;
    }

}
