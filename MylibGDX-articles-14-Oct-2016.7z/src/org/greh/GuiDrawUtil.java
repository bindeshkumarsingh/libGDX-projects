package org.greh;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.Texture.TextureFilter;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Matrix4;
import com.badlogic.gdx.utils.Disposable;

/**
 * Shared common data for rendering. Single instance with global access is very
 * helpful.
 */
public class GuiDrawUtil implements Disposable {
	public ShapeRenderer sr; // Left-Top origin
	public OrthographicCamera camera; // Left-Bottom origin
	public SpriteBatch batch; // Left-Bottom origin
//	public BitmapFont font, smallfont;
//	public Texture button_texture_default;

	public GuiDrawUtil() {
		camera = new OrthographicCamera();
		camera.setToOrtho(false, AppCfg.WIDTH, AppCfg.HEIGHT);
		batch = new SpriteBatch(); // Left-Bottom origin

//		button_texture_default = new Texture(
//				Gdx.files.internal("data/button.png"));
//		button_texture_default.setFilter(TextureFilter.Linear,
//				TextureFilter.Linear);

//		font = new BitmapFont(Gdx.files.internal("data/default.fnt"));
//		font.getRegion().getTexture()
//				.setFilter(TextureFilter.Linear, TextureFilter.Linear);
//		smallfont = new BitmapFont(Gdx.files.internal("data/default.fnt"));
//		smallfont.getRegion().getTexture()
//				.setFilter(TextureFilter.Linear, TextureFilter.Linear);
//		smallfont.getData().setScale(0.5f, 0.5f); // half size of font
		// sizes of font can also be set later

		// create a shape renderer in Screen coordinates. Left-Top origin.
		sr = new ShapeRenderer();
		Matrix4 ortho = new Matrix4();
		ortho.setToOrtho(0, AppCfg.WIDTH, AppCfg.HEIGHT, 0, 0, 1);
		sr.setProjectionMatrix(ortho);
	}

	@Override
	public void dispose() {
		batch.dispose();
                sr.dispose();
//		font.dispose();
//		smallfont.dispose();	
//		button_texture_default.dispose();
	}
}
