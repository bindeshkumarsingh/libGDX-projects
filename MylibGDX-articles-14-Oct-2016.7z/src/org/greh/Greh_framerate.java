package org.greh;

public class Greh_framerate {

    private final Greh_timer m_timer_fps = new Greh_timer();
    private final Greh_timer m_timer_fps_limit = new Greh_timer();
    private int m_fps = 0, m_count = 0, m_fps_limit = 30; // 30 fps default
    private long m_delay = 0;

    public Greh_framerate() {
        m_delay = (int) (1000.0f / m_fps_limit);
    }

    public void set_fps_limit(final int fps_limit) {
        if (fps_limit != 0) {
            m_fps_limit = fps_limit;
            m_delay = (int) (1000.0f / m_fps_limit);
        }
    }

    public int get_fps_limit() {
        return m_fps_limit;
    }

    public int get_fps() {
        return m_fps;
    }

    public Greh_timer get_fps_timer() {
        return m_timer_fps_limit;
    }

    public int calculate_fps() {
        m_count++;
        if (m_timer_fps.get_elapsed_time() >= 1000) {
            m_timer_fps.reset();
            m_fps = m_count;
            m_count = 0;
        }
        return m_fps;
    }

    public boolean keep_fps_in_limit() {
        long _samay = m_timer_fps_limit.get_elapsed_time();
        if (_samay < m_delay) {
            try {
                Thread.sleep(2);
            } catch (Exception exp) {
                return false;
            }
            return false;
        }
        m_timer_fps_limit.reset();
        return true;
    }
}
