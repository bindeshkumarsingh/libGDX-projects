package org.greh;

public class AppCfg {
    static public float WIDTH, HEIGHT;
    static public boolean DEBUG = true; // debug control flag

    static public void log( String msg ) {
        System.out.println(msg);
    }


    static public void log_exception( Exception e ) {
        System.out.println(e.getMessage());
    }
        
}
