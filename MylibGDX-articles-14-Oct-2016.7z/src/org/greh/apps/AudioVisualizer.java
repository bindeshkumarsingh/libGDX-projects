package org.greh.apps;

import org.greh.BaseApp;
import org.greh.ScreenBase;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Input;
import com.badlogic.gdx.audio.AudioRecorder;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import org.greh.AppCfg;
import org.greh.Greh_framerate;



public class AudioVisualizer extends ScreenBase {

    private final BaseApp APP;
    public OrthographicCamera m_cam;
    private SpriteBatch m_batch;

    // audio
    final private int FPS = 25;
    private AudioRecorder m_rec;
    private short m_samples[];
    private float m_lastX = 0, m_lastY = 0;
    
    // FPS limiter
    private Greh_framerate m_fps = new Greh_framerate();
    
    
    public AudioVisualizer(final BaseApp app) {
        APP = app;

        m_cam = new OrthographicCamera();
        m_cam.setToOrtho(false, Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        m_batch = new SpriteBatch();
        
        m_fps.set_fps_limit(FPS);
        
        try {

            // load resources here
            make_recorder();
            
        } catch (Exception ex) {
            AppCfg.log_exception(ex);
        }
        
    }


    public final void make_recorder() {
        if( m_rec == null ) {
            m_rec = Gdx.audio.newAudioRecorder(44100, true);
            m_samples = new short[ (int)(44100f / FPS)];            
        }
    }

    public void destroy_recorder() {
        if( m_rec != null ) {
            m_rec.dispose();
            m_rec = null;
        }
    }

    /**
     * Overridden to pause timer. Children must call super.pause().
     */
    @Override
    public void pause() {
        destroy_recorder();
    }

    void resizeBatch(int width, int height) {
        m_cam.setToOrtho(false, width, height);
        m_batch.setProjectionMatrix(m_cam.combined);
    }

    @Override
    public void renderMain(float delta) {

        if (Gdx.input.isKeyPressed(Input.Keys.BACK)) {
            Gdx.app.log("Debug", "back pressed!");
            quit();
            return;
        }

        // limit FPS
        while (!m_fps.keep_fps_in_limit()) {
            // sleeps in parts to sum total delay required to limit FPS.
            // returns true when total delay has been passed.
        }
        
        // dump FPS
//        System.out.println("FPS: " + m_fps.calculate_fps());
        
        
        // draw current to screen batch
        m_batch.enableBlending();
        m_batch.setBlendFunction(GL20.GL_BLEND_DST_RGB, GL20.GL_BLEND_SRC_ALPHA);
        m_batch.begin();
        Gdx.gl.glClearColor(0f, 0f, 0f, 1f);
        Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT | GL20.GL_DEPTH_BUFFER_BIT);
        resizeBatch(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());
        draw(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());        // draw current
        m_batch.end();

    }

    
    
    private void draw(float SW, float SH) {
        try {

            make_recorder();    // handle re-creation of recorder
            
            
            float Y = AppCfg.HEIGHT/2;
            
            m_rec.read(m_samples, 0, m_samples.length);
            
            APP.M_drawutil.sr.begin(ShapeRenderer.ShapeType.Filled);
            APP.M_drawutil.sr.setColor(Color.YELLOW);
             
            // convert total read samples to % and plot to screen width by %
            float delta = 1f, x = 0, sample;
            final int len = m_samples.length - 1;
            m_lastX = x;
            m_lastY = Y;
            float MIN = -1 * Short.MIN_VALUE;
            float MAX = Short.MAX_VALUE, percent;
            String values = "";
            for( float i = 0; i <= 100f; i += delta ) {
                percent = (i/100f);
                x = percent * AppCfg.WIDTH;
                sample = m_samples[(int)(percent * len)];
                if( sample == 0 ) {
                    continue;
                }
                
                values += " " + sample;
                
                // convert sample to float i.e. between -1.0f & +1.0f
                if( sample < 0 ) {
                    sample /= MIN;
                } else {
                    sample /= MAX;
                }
                
                float y = Y + sample * AppCfg.HEIGHT;
                
                box( x, y, 0, 1f );
                line( x, y, 0, m_lastX, m_lastY, 0, 1f, 1f, 1f, 1f );
                
                m_lastX = x;
                m_lastY = y;
            }
            APP.M_drawutil.sr.end();

//            System.out.println("Samples: " + values);
        } catch (Exception exp) {
            AppCfg.log_exception(exp);
        }
    }


    private void pixel(float x, float y, float z) {
        APP.M_drawutil.sr.point(x, y, z);
    }

    private void box(float x, float y, float z, float size) {
//        ShapeRenderer.ShapeType st = sr.getCurrentType();
//        sr.set(ShapeRenderer.ShapeType.Filled);
        APP.M_drawutil.sr.box(x, y, z, size, size, size);
//        sr.set(st);
    }

    
    private Color line_color;
    private void line(float x1, float y1, float z1, 
            float x2, float y2, float z2, 
            float r, float g, float b, float a) {
        
        if (line_color == null) {
            line_color = APP.M_drawutil.sr.getColor().cpy();
        } else {
            line_color.set(APP.M_drawutil.sr.getColor());
        }
        APP.M_drawutil.sr.getColor().set(r, g, b, a);
        APP.M_drawutil.sr.line(x1, y1, z1, x2, y2, z2);
        APP.M_drawutil.sr.getColor().set(line_color);
    }
    

    public void quit() {
        dispose();
        Gdx.app.exit();
    }

    @Override
    public void disposeMain() {
        m_batch.dispose();
        destroy_recorder();
    }

    
    @Override
    public void resize(int width, int height) {
        // Greh_manager.log(this, "App resize");
        m_cam.viewportWidth = width;
        m_cam.viewportHeight = height;
        m_cam.update();
    }

}
