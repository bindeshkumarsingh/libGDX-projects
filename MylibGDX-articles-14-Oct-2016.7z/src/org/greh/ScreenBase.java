package org.greh;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;

public abstract class ScreenBase implements Screen {

    protected boolean m_disposed = false;
    private boolean m_first_run = true;
    private final String ID = "" + this;

    public ScreenBase() {

    }

    @Override
    public void render(float delta) {
        if (m_disposed) {
            return;
        }

        if (m_first_run) {
            // flag to avoid 1st delta which can be very high many times.
            m_first_run = false;
        } else {
            renderMain(Gdx.graphics.getDeltaTime());
        }
    }

    /**
     * Overridden to pause timer. Children must call super.pause().
     */
    @Override
    public void pause() {

    }

    /**
     * Overridden to resume timer. Children must call super.resume().
     */
    @Override
    public void resume() {

    }

    @Override
    public void show() {

    }

    @Override
    public void hide() {

    }

    @Override
    public void resize(int width, int height) {

    }

    /**
     * Overridden to protect accidental multiple dispose. dispose() must be
     * called manually which will call disposeMain() once.
     */
    @Override
    public void dispose() {
        if (m_disposed) {
            return;
        }
        m_disposed = true;
        disposeMain();
    }

    public boolean disposed() {
        return m_disposed;
    }

    protected abstract void renderMain(float delta);

    protected abstract void disposeMain();

}
