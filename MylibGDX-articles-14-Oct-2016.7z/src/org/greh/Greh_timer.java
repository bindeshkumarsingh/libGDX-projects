// Exports
package org.greh;

/**
 *
 * @author bindesh
 */
public class Greh_timer {

    protected boolean m_pause = false;
    protected long m_pause_time = 0;
    protected String m_id = "GT_" + this;
    protected long m_last_time = 0, m_start_time = 0;

    public Greh_timer() {
        reset();
    }

    public Greh_timer(final String id) {
        reset();
        m_id = id;
    }

    public Greh_timer copy() {
        Greh_timer timer = new Greh_timer(m_id + "+");
        copy_to(timer);
        return timer;
    }

    public void copy_to(Greh_timer timer) {
        timer.m_last_time = m_last_time;
        timer.m_pause_time = m_pause_time;
        timer.m_start_time = m_start_time;
        timer.m_pause = m_pause;
    }

    public String get_id() {
        return m_id;
    }

    public void set_id(final String id) {
        m_id = id;
    }

    public final void reset() {
        m_start_time = time_milliseconds();
        m_last_time = m_start_time;
    }

    public void pause(final boolean b_pause) {
        m_pause = b_pause;
        if (m_pause) {
            m_pause_time = time_milliseconds();
        } else {
            if (m_pause_time == 0) { // already unpaused
                return;
            }
            long cur_time = time_milliseconds();
            long diff_time = cur_time - m_pause_time;
            // adjust elapsed time
            m_start_time += diff_time;
            m_last_time += diff_time;
            m_pause_time = 0;
        }
    }

    public boolean is_paused() {
        return m_pause;
    }

    public long get_elapsed_time() {
        if (m_pause) {
            return 0;
        }
        long cur_time = time_milliseconds();
        long diff_time = cur_time - m_start_time;
        return diff_time;
    }

    public long get_delta_time() {
        if (m_pause) {
            return 0;
        }
        long cur_time = time_milliseconds();
        long diff_time = cur_time - m_last_time;
        m_last_time = cur_time;
        return diff_time;
    }

    public void set_elapsed_time(final long elapsed_time_millis) {
        if (m_pause) {
            return;
        }
        long cur_time = time_milliseconds();
        m_start_time = cur_time - elapsed_time_millis;
    }

    static public void sleep(long _samay_millis) {
        try {
            Thread.sleep(_samay_millis);
        } catch (Exception e) {
            AppCfg.log_exception(e);
        }
    }

    static public long time_milliseconds() {
        return System.currentTimeMillis();
    }

    static public long time_microseconds() {
        // long nano = System.nanoTime();
        // long micro = nano / 1000;
        // long milli = micro / 1000;
        return System.nanoTime() / 1000;
    }

    static public long time_nanoseconds() {
        return System.nanoTime();
    }

}
