package platform;

import com.badlogic.gdx.backends.lwjgl.LwjglApplication;
import com.badlogic.gdx.backends.lwjgl.LwjglApplicationConfiguration;
import javax.swing.JComboBox;
import javax.swing.JOptionPane;
import org.greh.BaseApp;


// -Djava.library.path="/mnt/work/Software/java/libgdx-1.9.5/native/"

public class DesktopApp1 implements BaseApp.IOperatingSystemCommands {
    
    LwjglApplication APP;

    
    public DesktopApp1() {
        LwjglApplicationConfiguration config = new LwjglApplicationConfiguration();
        config.width = 800;
        config.height = 600;
//        config.setTitle("libGDX");
//        config.setWindowedMode(800, 600);
        APP = new LwjglApplication(new BaseApp(this), config);
    }
    
    
    public static void main(String[] args) {
        DesktopApp1 app = new DesktopApp1();
    }

    
    public void show_list(final String title, 
            final String[] texts, final Runnable[] runnables) {
        
        APP.postRunnable(new Runnable() {
            public void run() {
                JComboBox list = new JComboBox(texts);
                JOptionPane.showMessageDialog( null, list, title, JOptionPane.PLAIN_MESSAGE);
                // System.out.println(mixerInfo[list.getSelectedIndex()].getName());
                runnables[list.getSelectedIndex()].run();
            }            
        });
        
    }

    public void show_messagebox(String message) {
        
    }

    public void post_runnable(Runnable runnable) {
        APP.postRunnable(runnable);
    }

    public void command(int command, Object[] data) {
        
    }
}
